MY NEW YORK ZOO README

HOW TO LAUNCH
___

The solution is compiled using .NET Framework 4.5.
Exe is located here:

	/root/bin/release/MyNewYorkZoo.exe


COMMENTS & DISCUSSIONS
___

The purpose of this program is to simulate a zoo visit.  Our zoo will have constant size (it will have a fixed number exhibits, hard-coded and populated within the source code).  You start with a fixed amount of stamina points, visiting an exhibit costs 30 points.  When you deplete your stamina, you must exit the zoo.  Program ends when you exit the zoo.

The source code takes advantage of animal classes and class inheritance to classify animals.